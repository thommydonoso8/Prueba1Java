//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
  Departamento dep1 = new Departamento("PROP-D01", 65, 3, 8, false, true);
  Departamento dep2 = new Departamento("PROP-D02", 48, 2, 3, true, false);
  Casa casa1 = new Casa("PROP-C01", 120, 4, true);
  Casa casa2 = new Casa("PROP-C02", 90, 3, false);
  System.out.println("PROP-D01 (Departamento) registrada correctamente.");
  System.out.println("PROP-D02 (Departamento) registrada correctamente.");
  System.out.println("PROP-C01 (Casa) registrada correctamente.");
  System.out.println("PROP-C02 (Casa) registrada correctamente.");

  System.out.println();
  System.out.println(dep1);
  System.out.println(dep2);
  System.out.println(casa1);
  System.out.println(casa2);

}
