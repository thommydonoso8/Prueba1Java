public interface ConEstacionamiento {
    public String tieneEstacionamiento();
    public String asignarEstacionamiento();
}
