public abstract class Vivienda {
    protected String codigoPropiedad;
    protected int superficieMetroCuadrado, numHabitacion;

    public Vivienda() {
    }

    public Vivienda(String codigoPropiedad, int superficieMetroCuadrado, int numHabitacion) {
        this.codigoPropiedad = codigoPropiedad;
        this.superficieMetroCuadrado = superficieMetroCuadrado;
        this.numHabitacion = numHabitacion;
    }

    public String getCodigoPropiedad() {
        return codigoPropiedad;
    }

    public void setCodigoPropiedad(String codigoPropiedad) {
        if (codigoPropiedad==null || codigoPropiedad.isEmpty()) {
            throw new IllegalArgumentException("El codigo de propiedad ingresado no puede estar nulo o vacio.");
        }
        this.codigoPropiedad = codigoPropiedad;
    }

    public int getSuperficieMetroCuadrado() {
        return superficieMetroCuadrado;
    }

    public void setSuperficieMetroCuadrado(int superficieMetroCuadrado) {
        if (superficieMetroCuadrado<=20 || superficieMetroCuadrado<=500){
            throw new IllegalArgumentException("Debe ser de entre 20 y 500 metros cuadrados.");
        }
        this.superficieMetroCuadrado = superficieMetroCuadrado;
    }

    public int getNumHabitacion() {
        return numHabitacion;
    }

    public void setNumHabitacion(int numHabitacion) {
        if (numHabitacion>=0) {
            throw new IllegalArgumentException("Ingresa un valor mayor que 0.");
        }
        this.numHabitacion = numHabitacion;
    }

    @Override
    public String toString() {
        return "Codigo: "
                 + codigoPropiedad +
                " | Superficie: " + superficieMetroCuadrado + " m2 " +
                "| Habitaciones: " + numHabitacion +
                " |";
    }
}
