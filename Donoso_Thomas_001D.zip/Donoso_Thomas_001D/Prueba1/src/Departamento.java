public class Departamento extends Vivienda implements ConEstacionamiento{
    private int numeroPiso;
    private Boolean gastoComunAldia, estacionamientoAsignado;

    public Departamento() {
    }

    public Departamento(String codigoPropiedad, int superficieMetroCuadrado, int numHabitacion, int numeroPiso, Boolean gastoComunAldia, Boolean estacionamientoAsignado) {
        super(codigoPropiedad, superficieMetroCuadrado, numHabitacion);
        this.numeroPiso = numeroPiso;
        this.gastoComunAldia = gastoComunAldia;
        this.estacionamientoAsignado = estacionamientoAsignado;
    }

    public int getNumeroPiso() {
        return numeroPiso;
    }

    public void setNumeroPiso(int numeroPiso) {
        this.numeroPiso = numeroPiso;
    }

    public Boolean getGastoComunAldia() {
        return gastoComunAldia;
    }

    public void setGastoComunAldia(Boolean gastoComunAldia) {
        this.gastoComunAldia = gastoComunAldia;
    }

    public Boolean getEstacionamientoAsignado() {
        return estacionamientoAsignado;
    }

    public void setEstacionamientoAsignado(Boolean estacionamientoAsignado) {
        this.estacionamientoAsignado = estacionamientoAsignado;
    }

    @Override
    public String toString() {
        return super.toString() + " Piso: " +
                 numeroPiso +
                " | Gasto comun al dia: " + gastoComunAldia +
                " | Estacionamiento asignado: " + estacionamientoAsignado
                ;
    }

    @Override
    public String tieneEstacionamiento() {
        if(estacionamientoAsignado==true){
            return ("Si, esta propiedad tiene estacionamiento asignado.");
        }else{
            return ("No, esta propiedad no tiene estacionamiento asignado.");
        }
    }

    @Override
    public String asignarEstacionamiento() {
        if (estacionamientoAsignado == false) {
            estacionamientoAsignado = true;
        return ("Estacionamiento asignado");
        } else{
            return ("Esta propiedad ya tiene un departamento asignado.");
        }
    }




}
