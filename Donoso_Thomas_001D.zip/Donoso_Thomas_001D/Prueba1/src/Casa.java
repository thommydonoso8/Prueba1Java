public class Casa extends Vivienda implements ConEstacionamiento{
    private Boolean tienePatio;

    public Casa() {
    }

    public Casa(String codigoPropiedad, int superficieMetroCuadrado, int numHabitacion, Boolean tienePatio) {
        super(codigoPropiedad, superficieMetroCuadrado, numHabitacion);
        this.tienePatio = tienePatio;
    }

    public Boolean getTienePatio() {
        return tienePatio;
    }

    public void setTienePatio(Boolean tienePatio) {
        this.tienePatio = tienePatio;
    }

    @Override
    public String toString() {
        return super.toString() +
                " ¿Tiene patio? " + tienePatio
                ;
    }

    @Override
    public String tieneEstacionamiento() {
        return "";
    }

    @Override
    public String asignarEstacionamiento() {
        return "";
    }
}
