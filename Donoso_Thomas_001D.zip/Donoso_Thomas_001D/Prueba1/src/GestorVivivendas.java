import java.util.ArrayList;

public class GestorVivivendas {
     ArrayList<Vivienda>vivienda;

    public GestorVivivendas() {
    }
}
